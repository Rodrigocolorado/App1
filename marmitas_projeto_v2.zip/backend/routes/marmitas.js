const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/', (req, res) => {
 db.all('SELECT * FROM marmitas', [], (err, rows) => {
   if (err) return res.status(500).json({ error: err.message });
   res.json(rows);
 });
});

router.post('/', (req, res) => {
 const { nome, ingredientes, preco, imagem } = req.body;
 const sql = `INSERT INTO marmitas (nome, ingredientes, preco, imagem) VALUES (?, ?, ?, ?)`;
 
 db.run(sql, [nome, ingredientes, preco, imagem], function(err) {
   if (err) return res.status(400).json({ error: err.message });
   res.json({ id: this.lastID, nome, ingredientes, preco, imagem });
 });
});

router.delete('/:id', (req, res) => {
 const { id } = req.params;
 db.run('DELETE FROM marmitas WHERE id = ?', id, function(err) {
   if (err) return res.status(500).json({ error: err.message });
   res.json({ message: 'Marmita deletada com sucesso' });
 });
});

module.exports = router;