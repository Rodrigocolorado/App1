const express = require('express');
const router = express.Router();
const db = require('../db');

router.post('/', (req, res) => {
 const { cliente_nome, cliente_endereco, itens, total } = req.body;
 const itensString = JSON.stringify(itens);
 const sql = `INSERT INTO pedidos (cliente_nome, cliente_endereco, itens, total) VALUES (?, ?, ?, ?)`;
 
 db.run(sql, [cliente_nome, cliente_endereco, itensString, total], function(err) {
   if (err) return res.status(400).json({ error: err.message });
   res.json({ message: 'Pedido realizado com sucesso!', id: this.lastID });
 });
});

router.get('/', (req, res) => {
 db.all('SELECT * FROM pedidos ORDER BY id DESC', [], (err, rows) => {
   if (err) return res.status(500).json({ error: err.message });
   const pedidosFormatados = rows.map(pedido => ({
     ...pedido,
     itens: JSON.parse(pedido.itens)
   }));
   res.json(pedidosFormatados);
 });
});

module.exports = router;