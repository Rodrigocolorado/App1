const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, 'marmitas.db');

const db = new sqlite3.Database(dbPath, (err) => {
 if (err) console.error('Erro ao conectar ao SQLite:', err.message);
 else console.log('Conectado ao banco de dados SQLite.');
});

db.serialize(() => {
 db.run(`CREATE TABLE IF NOT EXISTS marmitas (
   id INTEGER PRIMARY KEY AUTOINCREMENT,
   nome TEXT NOT NULL,
   ingredientes TEXT,
   preco REAL NOT NULL,
   imagem TEXT
 )`);

 db.run(`CREATE TABLE IF NOT EXISTS pedidos (
   id INTEGER PRIMARY KEY AUTOINCREMENT,
   cliente_nome TEXT NOT NULL,
   cliente_endereco TEXT NOT NULL,
   itens TEXT NOT NULL, 
   total REAL NOT NULL,
   status TEXT DEFAULT 'Pendente',
   data_pedido DATETIME DEFAULT CURRENT_TIMESTAMP
 )`);
});

module.exports = db;