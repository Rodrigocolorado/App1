import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Carrinho from './pages/Carrinho';
import AdminMarmitas from './pages/admin/AdminMarmitas';

function App() {
 return (
   <BrowserRouter>
     <nav style={{ padding: '1rem', background: '#eee', marginBottom: '20px' }}>
       <Link to="/" style={{ marginRight: '15px', fontWeight: 'bold' }}>Cardápio</Link>
       <Link to="/carrinho" style={{ marginRight: '15px', fontWeight: 'bold' }}>Carrinho</Link>
       <Link to="/admin" style={{ color: 'red' }}>Admin (Gestão)</Link>
     </nav>
     <Routes>
       <Route path="/" element={<Home />} />
       <Route path="/carrinho" element={<Carrinho />} />
       <Route path="/admin" element={<AdminMarmitas />} />
     </Routes>
   </BrowserRouter>
 );
}

export default App;