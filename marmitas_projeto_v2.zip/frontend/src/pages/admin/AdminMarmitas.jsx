import { useState, useEffect } from 'react';
import api from '../../api/api';

function AdminMarmitas() {
 const [marmitas, setMarmitas] = useState([]);
 const [form, setForm] = useState({ nome: '', ingredientes: '', preco: '', imagem: '' });

 const carregarMarmitas = async () => {
   try {
       const res = await api.get('/marmitas');
       setMarmitas(res.data);
   } catch (err) { console.error(err); }
 };

 useEffect(() => { carregarMarmitas(); }, []);

 const salvar = async (e) => {
   e.preventDefault();
   await api.post('/marmitas', { ...form, preco: parseFloat(form.preco) });
   setForm({ nome: '', ingredientes: '', preco: '', imagem: '' });
   carregarMarmitas();
 };

 const deletar = async (id) => {
   if(!confirm("Tem certeza?")) return;
   await api.delete(`/marmitas/${id}`);
   carregarMarmitas();
 };

 return (
   <div className="container">
     <h2>Gerenciar Marmitas</h2>
     <form onSubmit={salvar} className="form-checkout" style={{marginBottom: '40px'}}>
       <input placeholder="Nome da Marmita" value={form.nome} onChange={e => setForm({...form, nome: e.target.value})} required />
       <input placeholder="Ingredientes" value={form.ingredientes} onChange={e => setForm({...form, ingredientes: e.target.value})} />
       <input placeholder="Preço (ex: 15.90)" type="number" step="0.01" value={form.preco} onChange={e => setForm({...form, preco: e.target.value})} required />
       <input placeholder="URL da Imagem (opcional)" value={form.imagem} onChange={e => setForm({...form, imagem: e.target.value})} />
       <button type="submit">Adicionar ao Cardápio</button>
     </form>

     <h3>Itens Cadastrados</h3>
     <ul style={{listStyle: 'none', padding: 0}}>
       {marmitas.map(m => (
         <li key={m.id} style={{padding: '10px', border: '1px solid #eee', marginBottom: '5px', display: 'flex', justifyContent: 'space-between'}}>
           <span>{m.nome} - <strong>R${m.preco}</strong></span>
           <button onClick={() => deletar(m.id)} style={{background: 'red', padding: '5px 10px'}}>X</button>
         </li>
       ))}
     </ul>
   </div>
 );
}
export default AdminMarmitas;