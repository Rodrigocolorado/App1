import { useState, useEffect } from 'react';
import api from '../api/api';
import { useNavigate } from 'react-router-dom';

function Carrinho() {
 const [itens, setItens] = useState([]);
 const [cliente, setCliente] = useState({ nome: '', endereco: '' });
 const navigate = useNavigate();

 useEffect(() => {
   const carrinhoSalvo = JSON.parse(localStorage.getItem('carrinho')) || [];
   setItens(carrinhoSalvo);
 }, []);

 const total = itens.reduce((acc, item) => acc + item.preco, 0);

 const finalizarPedido = async () => {
   if (itens.length === 0) return alert('Seu carrinho está vazio!');
   if (!cliente.nome || !cliente.endereco) return alert('Preencha seus dados!');

   try {
     await api.post('/pedidos', {
       cliente_nome: cliente.nome,
       cliente_endereco: cliente.endereco,
       itens: itens,
       total: total
     });

     alert('Pedido realizado com sucesso!');
     localStorage.removeItem('carrinho');
     setItens([]);
     navigate('/');
   } catch (error) {
     console.error('Erro ao finalizar:', error);
     alert('Erro ao processar pedido.');
   }
 };

 return (
   <div className="container">
     <h1>Seu Carrinho</h1>
     {itens.length === 0 ? <p>Vazio...</p> : (
       <ul style={{listStyle: 'none', padding: 0}}>
         {itens.map((item, index) => (
           <li key={index} style={{borderBottom: '1px solid #eee', padding: '10px 0'}}>
             {item.nome} - <strong>R$ {item.preco.toFixed(2)}</strong>
           </li>
         ))}
       </ul>
     )}
     <h3>Total: R$ {total.toFixed(2)}</h3>

     <div className="form-checkout">
       <h4>Finalizar Pedido</h4>
       <input 
         placeholder="Seu Nome" 
         value={cliente.nome}
         onChange={e => setCliente({...cliente, nome: e.target.value})}
       />
       <input 
         placeholder="Seu Endereço" 
         value={cliente.endereco}
         onChange={e => setCliente({...cliente, endereco: e.target.value})}
       />
       <button onClick={finalizarPedido}>Confirmar Compra</button>
     </div>
   </div>
 );
}
export default Carrinho;