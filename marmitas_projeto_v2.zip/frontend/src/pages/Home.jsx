import { useState, useEffect } from 'react';
import api from '../api/api';

function Home() {
 const [marmitas, setMarmitas] = useState([]);
 const [loading, setLoading] = useState(true);

 const adicionarAoCarrinho = (marmita) => {
   const carrinhoAtual = JSON.parse(localStorage.getItem('carrinho')) || [];
   carrinhoAtual.push(marmita);
   localStorage.setItem('carrinho', JSON.stringify(carrinhoAtual));
   alert(`${marmita.nome} adicionada ao carrinho!`);
 };

 useEffect(() => {
   api.get('/marmitas')
     .then((response) => {
       setMarmitas(response.data);
       setLoading(false);
     })
     .catch((error) => {
       console.error("Erro ao buscar marmitas:", error);
       setLoading(false);
     });
 }, []);

 if (loading) return <p style={{padding:'20px'}}>Carregando cardápio...</p>;

 return (
   <div className="container">
     <h1>Nosso Cardápio</h1>
     <div className="marmitas-grid">
       {marmitas.map((item) => (
         <div key={item.id} className="card">
           <img src={item.imagem || 'https://via.placeholder.com/150'} alt={item.nome} />
           <h3>{item.nome}</h3>
           <p>{item.ingredientes}</p>
           <p className="preco">R$ {item.preco.toFixed(2)}</p>
           <button onClick={() => adicionarAoCarrinho(item)}>Comprar</button>
         </div>
       ))}
     </div>
   </div>
 );
}
export default Home;